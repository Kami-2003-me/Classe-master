# Charger les bibliothèques nécessaires
library(MASS) # Pour la régression binomiale négative
library(pscl) # pour le test de surdispersion
install.packages("AER")
install.packages("COUNT")

# CAS 1: La variable dépendante est le " Nombre de visites d'un site web", la variable indépendante est "Nombre de publications sur les reseaux sociaux"
# Charger les données binomiales négatives
#  on effectue d'abord une Régression de Poisson sur les données
nb_model <- glm(Negative_Binomial_Data$Nombre_visites ~ Negative_Binomial_Data$Nombre_pub_reseaux, family = "poisson")
summary(nb_model)

# Test de surdispersion 
#vérification 1:
dispersiontest(nb_model)# la p value est inférieur à 0.05 , indiquant une surdispersion
#vérification 2:
deviance_residuelle=deviance(nb_model)
degres_liberte=df.residual(nb_model)
ratio=deviance_residuelle/degres_liberte # le ratio de déviance résiduelle est élevé , indiquant une surdispersion
# etant donné une surdispersion, la regression de poisson n'est plus appropriée, il fauut donc une regression binomiale négative

# Regression Binomiale négative sur les données
nb_model2= glm.nb(Negative_Binomial_Data$Nombre_visites ~ Negative_Binomial_Data$Nombre_pub_reseaux, data = Negative_Binomial_Data)
summary(nb_model2)

# Comparaison des modèles
# Coefficients : représentent l'effet de la variable indépendante sur le logarithme du taux de comptage attendu
coef(nb_model)# a ce niveau, on modelise le nombre de visites d'un site web en fonction du nombre de publicités diffusées sur les reseaux sociaux
# un coefficient de 0.116 pour la variable "publicité", signifierait q'une publicité suplémentaire est associée à une augmentation d'environ 11.6% du nombre de visites(exp(0.116)=1.116)

coef(nb_model2)# cas de la correction avec la regression binomiale négative

# Intervalles de confiance
confint(nb_model2)
confint(nb_model)

# Valeurs prédites
nb_predictions_2 <- predict(nb_model2, type = "response") # regression binomiale négative
nb_predictions <- predict(nb_model, type = "response")# regression de poisson

#Graphiques
# cas ou on a fait une regression de poisson
plot(Negative_Binomial_Data$Nombre_pub_reseaux, Negative_Binomial_Data$Nombre_visites, main = "POISSON_DATA_NB", xlab = "Nombre_pub_reseaux", ylab = "Nombre_visites")
lines(Negative_Binomial_Data$Nombre_pub_reseaux, nb_predictions, col = "blue")

#cas ou on a corrigé avec la regression binomiale négative
plot(Negative_Binomial_Data$Nombre_pub_reseaux, Negative_Binomial_Data$Nombre_visites, main = "POISSON_DATA_NB", xlab = "Nombre_pub_reseaux", ylab = "Nombre_visites")
lines(Negative_Binomial_Data$Nombre_pub_reseaux, nb_predictions_2, col = "red")
# les lignes rouge et bleu représentent les prédictions faites par les modèles
#il faut comparer la proximité de ces lignes aux observations, et on remarque que celle de la regression binomiale negative est plus proches des valeurs observées, alors ce modèle est meilleur


# Comparaison visuelle des résidus pour vérifier la qualité de l'ajustement
par(mfrow=c(1,2))
plot(resid(nb_model2, type = "deviance"), main = "Résidus Binomiale Négative")
plot(resid(nb_model, type = "deviance"), main = "Résidus_Poisson_NB")

#Comparer les AIC
AIC(nb_model2)
AIC(nb_model)
# Comparer les BIC
BIC(nb_model2)
BIC(nb_model)
# on remarque le modèle binomial négatif a l'AIC le plus faible alors l'ajustement avec ce modèle est meilleur
#***************************************************************************#
#CAS 2: La variable dépendante est le " Nombre de visites d'un site web", les variables indépendantes sont "Nombre d'E-mails marketing envoyés" et  "Nombre de publications sur les reseaux sociaux"
# Charger les données binomiales négatives
#  on effectue d'abord une Régression de Poisson sur les données
nb_model <- glm(Negative_Binomial_Data$Nombre_visites ~ Negative_Binomial_Data$Nombre_pub_reseaux+ Negative_Binomial_Data$`nombre_E-mails`, family = "poisson")
summary(nb_model)

# Test de surdispersion 
#vérification 1:
dispersiontest(nb_model)# la p value est inférieur à 0.05 , indiquant une surdispersion
#vérification 2:
deviance_residuelle=deviance(nb_model)
degres_liberte=df.residual(nb_model)
ratio=deviance_residuelle/degres_liberte # le ratio de déviance résiduelle est élevé , indiquant une surdispersion
# etant donné une surdispersion, la regression de poisson n'est plus appropriée, il fauut donc une regression binomiale négative

# Regression Binomiale négative sur les données
nb_model2= glm.nb(Negative_Binomial_Data$Nombre_visites ~ Negative_Binomial_Data$Nombre_pub_reseaux+Negative_Binomial_Data$`nombre_E-mails`, data = Negative_Binomial_Data)
summary(nb_model2)

# Comparaison des modèles
# Coefficients : représentent l'effet de la variable indépendante sur le logarithme du taux de comptage attendu
coef(nb_model)# a ce niveau, on modelise le nombre de visites du site web en fonction du nombre de publicités diffusées sur les reseaux
# un coefficient de 0.970 pour la variable "publicité", signifierait q'une publicité spplémentaire est associée à une augmentation d'environ 97.0% du nombre de visites du site(exp(0.970)=2.636)

coef(nb_model2)# cas de la correction avec la regression binomiale négative

# Intervalles de confiance
confint(nb_model2)
confint(nb_model)

# Valeurs prédites
nb_predictions_2 <- predict(nb_model2, type = "response") # regression binomiale négative
nb_predictions <- predict(nb_model, type = "response")# regression de poisson

#Graphiques
# cas ou on a fait une regression de poisson
plot(Negative_Binomial_Data$Nombre_pub_reseaux+Negative_Binomial_Data$`nombre_E-mails`, Negative_Binomial_Data$Nombre_visites, main = "POISSON_DATA_NB", xlab = "Nombre_pub_reseaux", ylab = "Nombre_visites")
lines(Negative_Binomial_Data$Nombre_pub_reseaux+Negative_Binomial_Data$`nombre_E-mails`, nb_predictions, col = "blue")

#cas ou on a corrigé avec la regression binomiale négative
plot(Negative_Binomial_Data$Nombre_pub_reseaux+Negative_Binomial_Data$`nombre_E-mails`, Negative_Binomial_Data$Nombre_visites, main = "POISSON_DATA_NB", xlab = "Nombre_pub_reseaux", ylab = "Nombre_visites")
lines(Negative_Binomial_Data$Nombre_pub_reseaux+Negative_Binomial_Data$`nombre_E-mails`, nb_predictions_2, col = "red")
# les lignes rouge et bleu représentent les prédictions faites par les modèles
#il faut comparer la proximité de ces lignes aux observations, et on remarque que celle de la regression binomiale negative est plus proches des valeurs observées, alors ce modèle est meilleur


# Comparaison visuelle des résidus
par(mfrow=c(1,2))
plot(resid(nb_model2, type = "deviance"), main = "Résidus Binomiale Négative")
plot(resid(nb_model, type = "deviance"), main = "Résidus_Poisson_NB")

#Comparer les AIC
AIC(nb_model2)
AIC(nb_model)
