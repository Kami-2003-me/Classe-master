
# Génération de données fictives
set.seed(123)
x <- rnorm(100)
z <- rnorm(100)  # Une deuxième variable pour le modèle 2
y <- 3*x + rnorm(100)

# Modèle 1: Ajustement du estimer les paramètres (coefficients) qui permettent de mieux expliquer la relation entre les variables
modele <- lm(y ~ x)

# Calcul des critères AIC et BIC
aic_value <- AIC(modele)
bic_value <- BIC(modele)

# Affichage des résultats
cat("AIC:", aic_value, "\n")
cat("BIC:", bic_value, "\n")


#Modèle 2 : y en fonction de x et d'une nouvelle variable z
modele2 <- lm(y ~ x + z)

# Calcul des critères AIC et BIC
aic2 <- AIC(modele2)
bic2 <- BIC(modele2)


