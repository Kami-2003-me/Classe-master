B1 <- read_excel("C:/Users/HP/Desktop/B1.xlsx")
print(B1)
attach(B1) #rend visible les vecteurs 
mrl<- lm(Salaire~Age, data = B1)
summary(mrl)#%de la variance de la variable dépendante est expliqué par les variables independante,
#en d'autre terme le modele rend compte de la significativité de la variabilité des donné.on peut donc
#se demander porquoi 41% restant de la variance ne sont pas expliqué.
par(mfrow= c(1,2))
hist(residuals(mrl),main = "Histogramme")#histogramme des residu.
plot(Age, Salaire)
abline(mrl, col="red")# droite de regression
shapiro.test(resid(mrl))# test de normalité
plot(mrl, which = 3)
#on voit que dans la dispersion des points autour de la droite de regression  tend à 
#augmenter au fur et à mesure que l'age augmente.l'orsque l'on s'attache à valider ce 
#modele on constate sur le graphique des residu stardisées selon les valeurs approchés
#que la variance des résidu n'est pas homogene car on a une tendance croissante dans la 
#moyenne des residu standardisées (ligne rouge)cela traduit une dispersion plus importante
#du salaire lorsque l'age augmente.Au seuil de significativité de 5%, le test de Breush-
#Pagan rejette l'hypothèse d'homogeneité de la dispersion des residu.

#test de Bresh-Pagan
bptest(mrl)

#par conséquent, on ne peut pas acepter ce modele de regression linéaire et il faut 
#trouver une maniere de stabiliser la variance des residuus.Divers transformations des 
#variables existent.une transformation logarithmique des deux variables permet de 
#resoudre le probleme.
mrl1<- lm(log(Salaire)~log(Age), data = B1)
summary(mrl1)
par(mfrow= c(1,2))
plot(log(Age), log(Salaire), data = B1 )
abline(mrl1, col="red")
plot(mrl1, which = 3)

bptest(mrl1)
#d'apres le test le probleme de dispersion non homogene des residu a été resolue.Afin
#de mieux se rendre compte de l'importance de stabiliser la variance des résidu avant 
#d'utiliser un modele regressif pour faire des prédictions ci dessous on montre les 
#resultats des predictions avec les deux modeles (avec et sans logarithme pour les variables)
predict(mrl,newdata = list(Salaire = c(80,150),inetrval ="prediction"))#valeur prédite
#et intervalle de confiance à 95% pour deux valeur du salaire.

predict(mrl1,newdata = list(Salaire = c(80,150),inetrval ="prediction"))#valeur prédite
#et intervalle de confiance à 95% pour deux valeur du salaire apres transformation logarithmique.
#on constate que les salaire preditpar le modele lorsque les variable ne sont pas transformé
#est inférieur à la valeur prédite par le modele avec les transformation.
#on peut affirmer que lorsque l'on ignore la variance non homogene des residu, on commet 
#des erreurs de prédiction qui peuvent s'avérerer très significative selon le cas.

#Dans d autre situation , au lieu de transformer les variables par une transformation logarithmique
#il convient mieux d'utliser la transformation carrée.


B2 <- read_excel("C:/Users/HP/Desktop/B2.xlsx")
print(B2)
attach(B2)
mrL<- lm(X~Y, data = B2)
summary(mrL)
par(mfrow= c(1,2))
hist(residuals(mrL),main = "Histogramme")
plot(X,Y)
abline(mrL, col="red")
plot(mrL, which = 3)
bptest(mrL)

Y_carré <- Y^2
print(Y_carré)
mrL1<- lm(X~Y_carré, data = B2)
par(mfrow= c(1,2))
plot(X,Y_carré)
abline(mrL1, col="red")
plot(mrL, which = 3)
bptest(mrL1)

#transformation inverse
B3 <- read_excel("C:/Users/HP/Desktop/B3.xlsx")
print(B3)
attach(B3)
mRL<- lm(X~Y, data = B3)
summary(mRL)
par(mfrow= c(1,2))
hist(residuals(mRL),main = "Histogramme")
plot(X,Y)
abline(mRL, col="red")
plot(mRL, which = 3)
bptest(mRL)

Y_inverse<- 1/Y
print(Y_inverse)
mRL1<- lm(X~Y_inverse, data = B3)
par(mfrow= c(1,2))
plot(X,Y_inverse)
abline(mRL1, col="red")
plot(mRL, which = 3)
bptest(mRL1)
