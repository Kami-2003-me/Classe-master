# 1. Création du jeu de données
donnees <- data.frame(
  Genre = c("H", "H", "H", "H", "F", "F", "F", "F"),
  Tabagique = c("Oui", "Oui", "Non", "Non", "Oui", "Oui", "Non", "Non"),
  Maladie_cardiaque = c("Oui", "Non", "Oui", "Non", "Oui", "Non", "Oui", "Non"),
  Freq = c(30, 50, 20, 100, 25, 45, 15, 95)
)

# 2. Affichage du tableau de données 
print(donnees)

# 3. Transformation en tableau de contingence
tableau_contingence <- xtabs(Freq ~ Genre + Tabagique + Maladie_cardiaque, data = donnees)

# 4. Affichage du tableau de contingence
print(tableau_contingence)

# 5. Ajustement du modèle log-linéaire avec glm
modele_glm <- glm(Freq ~ Genre * Tabagique * Maladie_cardiaque, data = donnees, family = poisson())

# 6. Résumé du modèle
summary(modele_glm)

# 7. Test d'adéquation du modèle
anova <- anova(modele_glm, test = "Chisq")
print(anova)



