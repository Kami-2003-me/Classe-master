#Cette ligne de code charge le package MASS, 
#qui contient des fonctions pour l'analyse statistique, 
#y compris la fonction boxcox().
# Charger le package MASS
library(MASS)

#Charger une base de données
y <- c(1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 6, 7, 8)
x <- c(7, 7, 8, 3, 2, 4, 4, 6, 6, 7, 5, 3, 3, 5, 8)

#Cette ligne ajuste un modèle de régression linéaire simple 
#en utilisant lm() (linear model) avec y comme variable dépendante et x comme variable indépendante.
#Le résultat est stocké dans l'objet model.
# Ajuster un modèle de régression linéaire
model <- lm(y~x)

#Ces lignes de code utilisent la fonction boxcox() 
#pour estimer le paramètre de transformation 
#𝜆
#qui maximise la fonction de log-vraisemblance. La valeur optimale de 
#𝜆
#est extraite et affichée.
# Trouver le lambda optimal pour la transformation Box-Cox
bc <- boxcox(y ~ x)
(lambda <- bc$x[which.max(bc$y)])

#Cette ligne de code ajuste un nouveau modèle de régression linéaire 
#après avoir transformé les données y en utilisant la transformation Box-Cox avec le 
#𝜆
#optimal trouvé précédemment. Le nouveau modèle est stocké dans l'objet new_model.
# Ajuster un nouveau modèle de régression linéaire en utilisant la transformation Box-Cox
new_model <- lm(((y^lambda - 1) / lambda) ~ x)


#Ces lignes de code créent des Q-Q plots (quantile-quantile plots) pour comparer
#les résidus des deux modèles de régression.
#Les résidus du modèle initial sont tracés à gauche 
#et ceux du modèle transformé sont tracés à droite. 
#Les lignes de référence sont ajoutées avec qqline() pour évaluer
#la normalité des résidus.
# Comparer les résidus des deux modèles à l'aide de Q-Q plots
op <- par(pty = "s", mfrow = c(1, 2))
qqnorm(model$residuals)
qqline(model$residuals)
qqnorm(new_model$residuals)
qqline(new_model$residuals)
par(op)
