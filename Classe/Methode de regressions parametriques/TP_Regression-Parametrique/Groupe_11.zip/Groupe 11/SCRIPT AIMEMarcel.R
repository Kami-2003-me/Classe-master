install.packages("quantreg")
library(quantreg)


### Pr?parer vos donn?es
set.seed(123)
x <- seq(1, 10, by=0.1)
y <- 2 + 0.5 * x + rnorm(length(x), mean=0, sd=1)
data <- data.frame(x, y)

###  Ajuster le mod?le de r?gression quantile
# Ajustement de la r?gression quantile pour le quantile 0.5 (m?diane)
model <- rq(y ~ x, data=data, tau=0.5)
summary(model)

###  Visualiser les r?sultats
# Tracer les donn?es
plot(data$x, data$y, main="R?gression Quantile", xlab="X", ylab="Y", pch=19, col="blue", lwd=2)

# Ajouter la ligne de r?gression pour le quantile 0.5 (m?diane)
lines(data$x, predict(model), col="red", lwd=2)

# Ajuster ?galement d'autres quantiles si n?cessaire
model_25 <- rq(y ~ x, data=data, tau=0.25)
lines(data$x, predict(model_25), col="green", lwd=2)

model_75 <- rq(y ~ x, data=data, tau=0.75)
lines(data$x, predict(model_75), col="orange", lwd=2)

legend("topright", legend=c("Donn?es", "Quantile 0.5", "Quantile 0.25", "Quantile 0.75"),
       col=c("blue", "red", "green", "orange"), pch=c(19, NA, NA, NA), lty=c(NA, 1, 1, 1))


### Diagnostiquer le mod?le
# Calcul des r?sidus
residuals <- data$y - predict(model)

# Tracer les r?sidus
plot(data$x, residuals, main="R?sidus de la R?gression Quantile", xlab="X", ylab="R?sidus")
abline(h=0, col="red", lty=2)

###  Effectuer des pr?dictions
new_data <- data.frame(x=seq(1, 10, by=0.1))
predictions <- predict(model, new_data)
#Visualiser les pr?dictions

#Ajoutez les pr?dictions ? votre trac?.

# Tracer les pr?dictions
points(new_data$x, predictions, col="purple", pch=19, cex=0.5)

