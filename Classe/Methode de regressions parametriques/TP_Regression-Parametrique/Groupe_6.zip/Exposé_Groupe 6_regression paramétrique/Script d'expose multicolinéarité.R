# Génération des données
set.seed(123) # Pour la reproductibilité

# Nombre d'observations
n <- 50

# Génération des variables explicatives
a <- runif(n, 100, 1000)  # Surface totale du bâtiment (en m²)
b <- a * runif(n, 0.7, 1)  # Surface réfrigérée (très corrélée à a)
d <- sample(20:30, n, replace = TRUE)  # Nombre de jours de réfrigération

# Génération de la variable réponse avec du bruit
y <- 5 + 2*a + 3*b + 1.5*d + rnorm(n, mean = 0, sd = 100)

# Création du data frame
data <- data.frame(y, a, b, d)

# Affichage des premières lignes
head(data)

# Exporter en CSV si besoin
write.csv(data, "donnees_froid.csv", row.names = FALSE)

# Régression Linéaire et Problème de Multicolinéarité
model <- lm(y ~ a + b + d, data = data)
summary(model)

# Vérification de la Multicolinéarité avec le VIF (Variance Inflation Factor)

library(car) # Si non installé, faites install.packages("car")
vif(model)

# Réduction de la Multicolinéarité avec l'Analyse en Composantes Principales (PCA)
install.packages("FactoMineR")
library(FactoMineR)
pca <- PCA(data[, c("a", "b")], scale.unit = TRUE, graph = FALSE)
pca$var$coord  # Coordonnées des variables sur les axes principaux

# Régression Ridge pour Corriger la Multicolinéarité
library(glmnet)
X <- model.matrix(y ~ a + b + d, data)[, -1] # Matrice des prédicteurs sans l’intercept
Y <- data$y

# Grid de pénalisation lambda
lambda_seq <- 10^seq(4, -2, length = 100)

# Ajustement du modèle Ridge
ridge_model <- glmnet(X, Y, alpha = 0, lambda = lambda_seq)

# Validation croisée pour choisir lambda optimal
cv_ridge <- cv.glmnet(X, Y, alpha = 0)
best_lambda <- cv_ridge$lambda.min
best_lambda

# Ré-estimation du modèle Ridge avec le lambda optimal
ridge_final <- glmnet(X, Y, alpha = 0, lambda = best_lambda)
coef(ridge_final)



