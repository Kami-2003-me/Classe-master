# IV. Étude de cas et comparaison des méthodes

# 4.1 Présentation du jeu de données
## Utilisation de données aléatoires contenant des valeurs aberrantes
x <- c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20)
y <- c(8.99, 10.72, 15.30, 20.05, 19.53, 80, 29.16, 30.53, 31.06, 200.09, 
       37.07, 40.07, 44.48, 43.17, 46.55, -20, 53.97, 59.63, 60.18, 62.18)

# x = Période , y = Revenu
data <- data.frame(x, y)

# Résumé des données
summary(data)

# 4.2 Application des méthodes de détection sur R
## Ajustement du modèle de régression linéaire avec valeurs aberrantes
model_full <- lm(y ~ x, data = data)
summary(model_full)

## Visualisation des résidus avec valeurs aberrantes
par(mfrow = c(1, 2))
plot(model_full$fitted.values, model_full$residuals, 
     main = "Résidus avec valeurs aberrantes", xlab = "Valeurs ajustées", ylab = "Résidus")
abline(h = 0, col = "red")

## Détection des valeurs aberrantes avec l'IQR
Q1 <- quantile(data$y, 0.25)
Q3 <- quantile(data$y, 0.75)
IQR_value <- Q3 - Q1
lower_bound <- Q1 - 1.5 * IQR_value
upper_bound <- Q3 + 1.5 * IQR_value

## Suppression des valeurs aberrantes
data_clean <- data[data$y >= lower_bound & data$y <= upper_bound, ]

# 4.3 Évaluation des stratégies de traitement
## Impact sur les coefficients de régression
model_sans_aberrant <- lm(y ~ x, data = data_clean)
summary(model_sans_aberrant)

## Précision des prédictions
rmse <- function(actual, predicted) {
  sqrt(mean((actual - predicted)^2))
}

rmse_avant <- rmse(data$y, predict(model_full, data))
rmse_apres <- rmse(data_clean$y, predict(model_sans_aberrant, data_clean))

cat("RMSE avec valeurs aberrantes :", rmse_avant, "\n")
cat("RMSE après suppression des valeurs aberrantes :", rmse_apres, "\n")

## Robustesse du modèle
plot(model_sans_aberrant$fitted.values, model_sans_aberrant$residuals, 
     main = "Résidus après suppression des valeurs aberrantes", xlab = "Valeurs ajustées", ylab = "Résidus")
abline(h = 0, col = "blue")