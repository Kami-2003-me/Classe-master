# cas B-spline 
install.packages("splines")  
library(splines)

# Générer des données d'exemple
set.seed(42)
x <- sort(runif(100, 0, 5))#100 points entre 0 et 5
y <- sin(x) + rnorm(100, 0, 0.1)#sin avec bruit

#  Ajuster un modèle de régression spline
# Choisir le nombre de nœuds
n_knots <- 4
model <- lm(y ~ bs(x, knots = quantile(x, probs = seq(0, 1, length.out = n_knots + 2)[-c(1, n_knots + 2)])))

#  Résumé du modèle
summary(model)

# Visualisation des résultats
plot(x, y, main = "Régression Spline", xlab = "X", ylab = "y", pch = 19)
lines(x, predict(model), col = 'red', lwd = 2)

  
  ### une régression spline cubique
  

#  Générer des données d'exemple
set.seed(42)  # Pour la reproductibilité
x <- sort(runif(100, 0, 10))  # 100 points entre 0 et 10
y <- sin(x) + rnorm(100, 0, 0.1) # Sinus avec bruit

#  Ajuster un modèle de régression spline cubique
model <- lm(y ~ bs(x, degree = 3))  # Spline cubique

#  Résumé du modèle
summary(model)

# Visualisation des résultats
plot(x, y, main = "Régression Spline Cubique", xlab = "X", ylab = "y", pch = 19)
lines(x, predict(model), col = 'red', lwd = 2) # Ajouter la courbe d'ajustement

#  Ajouter les nœuds s'il y a lieu
# Utilisation de quantiles pour positionner les nœuds manuellement
knots <- quantile(x, probs = seq(0, 1, length.out = 5)[-c(1, 5)])  # 3 nœuds
model_with_knots <- lm(y ~ bs(x, knots = knots, degree = 3))

lines(x, predict(model_with_knots), col = 'blue', lwd = 2, lty = 2) # Courbe avec nœuds

# Ajouter une légende
legend("topright", legend = c("Ajustement Spline Cubique", "Ajustement avec Nœuds"), 
       col = c("red", "blue"), lty = 1:2, lwd = 2)



  
  ### cas d'une spline lineaire 



# 
set.seed(123)
x <- seq(1, 10, by=0.1)
y <- 2 + 3 * x + rnorm(length(x), mean=0, sd=1)
data <- data.frame(x, y)


###  Créer un modèle de régression spline linéaire


# Ajustement du modèle
model <- lm(y ~ bs(x, knots=c(4, 7)), data=data)


###  Résumé du modèle


summary(model)


### Étape 5 : Visualiser les résultats


# Tracer les données et la ligne de régression
plot(data$x, data$y, main="Régression Spline Linéaire", xlab="X", ylab="Y")
lines(data$x, predict(model), col="blue", lwd=2)


### Diagnostiquer le modèle


par(mfrow=c(2, 2))
plot(model)


###  Effectuer des prédictions


new_data <- data.frame(x=seq(1, 10, by=0.1))
predictions <- predict(model, new_data)


###  Visualiser les prédictions


lines(new_data$x, predictions, col="red", lwd=2)


