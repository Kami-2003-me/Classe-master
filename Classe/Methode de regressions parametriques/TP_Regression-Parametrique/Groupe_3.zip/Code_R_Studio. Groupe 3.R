base=read.csv2("revenu_depense.csv", header = TRUE)
library(ggplot2)
attach (base)

#Ajuster un modèle linéaire (prédire le revenu en fonction des dépenses)
modele_1=lm(Depense ~ Revenu, data = base)
modele_1

#Ajouter les résidus et les valeurs ajustées à la base de données
base_residu_1=residuals(modele_1)
base_prevu_1=fitted(modele_1)
base_residu_1
base_prevu_1

#Tracer le nuage de points des résidus par rapport aux dépenses prévues
plot(fitted(modele_1), residuals(modele_1),
     xlab = "Dépenses prévues", 
     ylab = "Résidus",
     main = "Nuage de points des résidus",
     col = "blue", pch = 16)
abline(h = 0, lty = 2, col = "red") 

# Effectuer le test de Breusch-Pagan
library(lmtest)
bptest(modele_1)

# Installer et charger le package sandwich pour une estimation robuste
install.packages("sandwich")
library
# Effectuer le test de White
bptest(modele_1, ~ Depense + I(Depense^2), data = base)


# Effectuer le test de Goldfeld-Quandt
install.packages("car")  # À installer une seule fois
library(car)
gq_result <- gqtest(modele_1)
print(gq_result)

data$log_Y <- log(Depense)

modele_1=lm(Revenu ~ Depense, data = base)
modele_1

log(Depense)
sqrt_revenu <- sqrt(Revenu)
sqrt_revenu

library(MASS)
boxcox(Revenu ~ 1, data = base)
boxcox(Depense ~ 1, data = base)

revenu_trans <- (Revenu^lambda_opt - 1) / lambda_opt

model_robust <- rlm(Revenu ~ Depense)
summary(model_robust)

library(sandwich)

# Calcul des erreurs-types robustes de White (Heteroskedasticity-Consistent, HC)
erreurs_types_robustes <- coeftest(modele_1, vcov = vcovHC(modele_1, type = "HC3"))
# Affichage des résultats avec erreurs-types robustes
print(erreurs_types_robustes)

covariance_robuste <- vcovHC(modele_1, type = "HC3")
covariance_robuste

coeftest(modele_1, vcov = covariance_robuste)
