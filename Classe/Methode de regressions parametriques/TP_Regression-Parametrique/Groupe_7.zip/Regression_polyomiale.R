##############Présentation de la base de donées######

#La base mtcars provient du magazine Motor Trend de 1974 et contient 32 modèles de voitures avec différentes caractéristiques.
#Elle est incluse dans R et accessible directement sans téléchargement.

# Charger les données
data(mtcars)
attach(mtcars)
mpg

# Afficher les premières lignes
head(mtcars)


###############Visualisation de mpg(la consommation de la voiture) et wt(le poids du vehicule)

#Avant d’appliquer la régression polynomiale, 
#il est important d’examiner la relation graphique entre les deux variables.

# Nuage de points mpg ~ wt

plot(mtcars$wt, mtcars$mpg, 
     main = "Relation entre le poids et la consommation",
     xlab = "Poids du véhicule (wt)", 
     ylab = "Consommation (mpg)", 
     pch = 19, col = "blue")

#On observe une tendance décroissante : plus le poids (wt) augmente, plus la consommation (mpg) diminue.
#La relation ne semble pas strictement linéaire, d’où l’intérêt d’une régression polynomiale.

##################Modèle de régression linéaire##################################

#Nous commençons par ajuster une régression linéaire simple 
#pour voir si elle explique bien la relation entre mpg et wt.


# Ajuster le modèle de régression linéaire
modele_lin <- lm(mpg ~ wt, data = mtcars)

# Résumé du modèle
summary(modele_lin)

#Si le coefficient de wt est négatif, cela confirme que plus le poids augmente, 
#plus la consommation diminue.

#############Ajout de la droite de régression#####################
abline(modele_lin, col = "red", lwd = 2)

###########Problème :

#La régression linéaire ne capture pas bien la courbure des données.
#Nous allons donc tester une régression polynomiale.

##########Régression Polynomiale de Degré 2####################

##Puisque la relation semble non linéaire, nous ajustons un modèle quadratique :

# Ajustement du modèle polynomiale de degré 2
modele_poly <- lm(mpg ~ poly(wt, 2, raw = TRUE), data = mtcars)

# Résumé du modèle
summary(modele_poly)

#On regarde si les coefficients de wt et wt² sont significatifs.
#On compare le R² du modèle polynomiale avec celui du modèle linéaire.

# Tracer les points
plot(mtcars$wt, mtcars$mpg, 
     main = "Régression polynomiale : mpg ~ wt",
     xlab = "Poids du véhicule (wt)", 
     ylab = "Consommation (mpg)", 
     pch = 19, col = "blue")

# Générer des prédictions pour wt entre min et max
wt_seq <- seq(min(mtcars$wt), max(mtcars$wt), length.out = 100)
mpg_pred <- predict(modele_poly, newdata = data.frame(wt = wt_seq))

# Ajouter la courbe polynomiale
lines(wt_seq, mpg_pred, col = "green", lwd = 2)
abline(modele_lin, col = "red", lwd = 2)
# Légende
legend("topright", legend = c("Données", "Régression linéaire", "Régression polynomiale"),
       col = c("blue", "red", "green"), pch = c(19, NA, NA), lty = c(NA, 1, 1), lwd = 2)

#######Analyse graphique#############
  
#La courbe verte suit mieux les points que la droite rouge.
#Cela confirme que le modèle polynomiale capture mieux la tendance des données.

summary(modele_lin)$r.squared  # R² du modèle linéaire
summary(modele_poly)$r.squared  # R² du modèle polynomiale

#Si 
#le R carré est plus élevé pour le modèle polynomiale,
#cela signifie que le modèle quadratique explique mieux la variabilité de la consommation (mpg).