-- Création de la base de données training
create schema train ;
use train ;

-- Création d'une table Employes
CREATE TABLE Employes (
    ID_Employe INT PRIMARY KEY,
    Nom VARCHAR(50),
    Prenom VARCHAR(50),
    Salaire DECIMAL(10,2),
    ID_Departement INT 
);
-- Cette requête crée une table Employes avec les colonnes ID_Employe, Nom, Prenom, Salaire et ID_Departement
-- Créons la table département

CREATE TABLE Departement (
    ID_Departement INT PRIMARY KEY AUTO_INCREMENT,
    Nom_Departement VARCHAR(100) NOT NULL,
    Localisation VARCHAR(100) NOT NULL
);


-- La commande ALTER est utilisée pour modifier une table existante (ajout, suppression ou modification de colonnes).
ALTER TABLE Employes  
ADD Email VARCHAR(100);
-- Cette requête ajoute une nouvelle colonne Email à la table Employes.

ALTER TABLE Employes  
DROP COLUMN Email;
-- Cette requête supprime la colonne Email de la table Employes.

-- Nous allons à présent ajouter des lignes à notre table employées
INSERT INTO Employes (ID_Employe, Nom, Prenom, Salaire, ID_Departement) VALUES
(1, 'Dupont', 'Jean', 3500.00, 2),
(2, 'Martin', 'Sophie', 3200.00, 1),
(3, 'Durand', 'Paul', 3700.00, 2),
(4, 'Bernard', 'Julie', 4100.00, 3),
(5, 'Lefevre', 'Thomas', 2900.00, 1),
(6, 'Morel', 'Camille', 3500.00, 2),
(7, 'Simon', 'Lucas', 3800.00, 3),
(8, 'Rousseau', 'Emma', 3600.00, 2),
(9, 'Lambert', 'Nathan', 3300.00, 1),
(10, 'Girard', 'Laura', 4000.00, 3),
(11, 'Noel', 'Antoine', 3400.00, 2);

/*
Chaque ligne insère un employé distinct avec son ID_Employe, Nom, Prenom, Salaire, et ID_Departement.
La valeur de ID_Employe est unique pour chaque employé.
Les employés sont répartis dans différents départements (ID_Departement = 1, 2 ou 3).
*/ 

-- Ajout de lignes à la table département

INSERT INTO Departement (Nom_Departement, Localisation) VALUES
('Ressources Humaines', 'Paris'),
('Informatique', 'Lyon'),
('Marketing', 'Marseille'),
('Finance', 'Bordeaux'),
('Production', 'Lille');


-- Sélection de toutes les colonnes de la table Employes
SELECT * FROM Employes;
-- Cette requête récupère toutes les colonnes de la table Employes.
SELECT Nom, Prenom, Salaire FROM Employes;
-- Cette requête affiche uniquement les colonnes Nom, Prenom et Salaire.

SELECT * FROM Employes
WHERE ID_Employe = 1 ;
-- Cette commande affiche la ligne de l'individu dont l'id employé est 1.

UPDATE Employes  
SET Salaire = 4000.00  
WHERE ID_Employe = 1;
-- Cette requête met à jour le salaire de l’employé ayant ID_Employe = 1 à 4000.

SELECT * FROM Employes
WHERE ID_Employe = 1 ;
-- Le salaire a bien changé dans la table

DELETE FROM Employes  
WHERE ID_Employe = 1;
-- Cette requête supprime l’employé avec ID_Employe = 1.
/* Les commandes Delete et Drop jouent le même de suppression mais
La commande Delete s'applique uniquement aux objets des tables contrairement à Drop qui s'applique à l'extérieur des tables.
*/

-- Requêtes étendues
use world ;
-- Nous considérons la base de données world

SELECT Name, Population  
FROM country  
WHERE Population > (SELECT AVG(Population) FROM country);
-- Cette requête sélectionne tous les pays dont la population est supérieure à la moyenne mondiale.
-- Il s'agait d'une requête imbriquée

WITH Population_Continent AS (
    SELECT Continent, SUM(Population) AS Total_Population
    FROM country
    GROUP BY Continent
)
SELECT Continent, Total_Population
FROM Population_Continent
WHERE Total_Population > 500000000;
-- Cette requête calcule la population totale par continent et filtre ceux ayant plus de 500 millions d’habitants.
-- Il s'agit d'une requête avec Expressions de Table Communes

SELECT Name, Continent, Population,  
       RANK() OVER (PARTITION BY Continent ORDER BY Population DESC) AS Rang_Population  
FROM country;
-- Cette requête classe les pays par population dans chaque continent (RANK())
-- Requêtes avec Fonctions Analytiques

WITH RECURSIVE Country_Hierarchy (CountryCode, Name, Parent) AS (
    SELECT Code, Name, NULL FROM country
    UNION ALL
    SELECT city.CountryCode, city.Name, country.Name
    FROM city
    JOIN country ON city.CountryCode = country.Code
)
SELECT * FROM Country_Hierarchy;
-- Cette requête construit une hiérarchie entre les pays et leurs villes (en particulier la capitale).
-- Requêtes Récursives
