-- Création de la base de données
CREATE DATABASE IF NOT EXISTS Commerce;
USE Commerce;

-- Schéma Initial (Non Normalisé)
CREATE TABLE Clients_Orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    client_name VARCHAR(100),
    client_email VARCHAR(100),
    product_name VARCHAR(100),
    quantity INT,
    order_date DATE
);

-- Insertion des Données
INSERT INTO Clients_Orders (client_name, client_email, product_name, quantity, order_date)
VALUES 
('Alice Doe', 'alice@example.com', 'Laptop', 1, '2025-03-01'),
('Alice Doe', 'alice@example.com', 'Mouse', 2, '2025-03-01'),
('Bob Smith', 'bob@example.com', 'Keyboard', 1, '2025-03-02');

-- Conversion du Schéma : Normalisation
CREATE TABLE Clients (
    client_id INT PRIMARY KEY AUTO_INCREMENT,
    client_name VARCHAR(100),
    client_email VARCHAR(100) UNIQUE
);

CREATE TABLE Produits (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100)
);

CREATE TABLE Commandes (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    client_id INT,
    product_id INT,
    quantity INT,
    order_date DATE,
    FOREIGN KEY (client_id) REFERENCES Clients(client_id),
    FOREIGN KEY (product_id) REFERENCES Produits(product_id)
);

-- Migration des Données
INSERT IGNORE INTO Clients (client_name, client_email)
SELECT DISTINCT client_name, client_email FROM Clients_Orders;

INSERT IGNORE INTO Produits (product_name)
SELECT DISTINCT product_name FROM Clients_Orders;

INSERT INTO Commandes (client_id, product_id, quantity, order_date)
SELECT 
    c.client_id, 
    p.product_id, 
    co.quantity, 
    co.order_date
FROM Clients_Orders co
JOIN Clients c ON co.client_email = c.client_email
JOIN Produits p ON co.product_name = p.product_name;

-- Vérification de la Conversion
SELECT * FROM Clients;
SELECT * FROM Produits;
SELECT * FROM Commandes;
