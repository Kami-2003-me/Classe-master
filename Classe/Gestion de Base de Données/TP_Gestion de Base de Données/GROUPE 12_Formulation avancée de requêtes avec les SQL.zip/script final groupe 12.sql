#Création d'une table exemple
CREATE TABLE Employers (
    ID INT PRIMARY KEY,
    Nom VARCHAR(100),
    Salaire DECIMAL(10, 2),
    ManagerID INT,
    DateEmbauche DATE
);

-- Insérer des données exemple
INSERT INTO Employers (ID, Nom, Salaire, ManagerID, DateEmbauche) VALUES
(1, 'Alice', 70000, NULL, '2021-01-10'),
(2, 'Bob', 60000, 1, '2021-02-15'),
(3, 'Charlie', 50000, 1, '2021-03-20'),
(4, 'Dave', 40000, 2, '2021-04-25'),
(5, 'Eve', 30000, 3, '2021-05-30');

-- Fonction de fenêtrage : Calculer le salaire moyen par manager
SELECT 
    ManagerID,
    AVG(Salaire) OVER (PARTITION BY ManagerID) AS SalaireMoyen,
    COUNT(*) OVER (PARTITION BY ManagerID) AS NombreEmployers
FROM Employers
WHERE ManagerID IS NOT NULL;

-- CTE pour récupérer tous les employés et leurs gestionnaires
WITH EmployersCTE AS (
    SELECT 
        e.ID,
        e.Nom,
        e.Salaire,
        e.ManagerID,
        m.Nom AS NomManager
    FROM Employers e
    LEFT JOIN Employers m ON e.ManagerID = m.ID
)
SELECT * FROM EmployersCTE;

-- Requête récursive pour générer une hiérarchie des employés
WITH RECURSIVE Hierarchie AS (
    SELECT ID, Nom, ManagerID, 0 AS Niveau
    FROM Employers
    WHERE ManagerID IS NULL
    UNION ALL
    SELECT e.ID, e.Nom, e.ManagerID, Niveau + 1
    FROM Employers e
    INNER JOIN Hierarchie h ON e.ManagerID = h.ID
)
SELECT * FROM Hierarchie;

-- Gestion des NULL : Sélectionner tous les employés et remplacer les NULL par 'Aucun Manager'
SELECT 
    ID,
    Nom,
    COALESCE(NomManager, 'Aucun Manager') AS NomManager
FROM (
    SELECT 
        e.ID,
        e.Nom,
        m.Nom AS NomManager
    FROM Employers e
    LEFT JOIN Employers m ON e.ManagerID = m.ID
) AS SousRequete;

-- Optimisation des transactions et verrouillage
BEGIN TRANSACTION;

-- Un exemple d'insertion qui pourrait être sous verrouillage
INSERT INTO Employers (ID, Nom, Salaire, ManagerID, DateEmbauche) 
VALUES (6, 'Frank', 35000, 2, '2021-06-30');

-- Commencer un verrouillage explicite sur l'enregistrement de Bob
SELECT * FROM Employers WHERE ID = 2 FOR UPDATE;

COMMIT;
