## des Données et Clustering
# Chargement des packages
library(cluster)      # Pour les méthodes de clustering et évaluation
library(factoextra)   # Pour la visualisation
library(NbClust)      # Pour déterminer le nombre optimal de clusters

# Exemple avec le jeu de données iris (sans les étiquettes)
data(iris)
df <- iris[, -5]  # Suppression de la colonne "Species" (étiquette réelle)

# Normalisation des données (important pour k-means)
df_scaled <- scale(df)

# Clustering avec k-means (k=3)
set.seed(123)
km_res <- kmeans(df_scaled, centers = 3, nstart = 25)


##Évaluation par Critères Internes

#Indice de Silhouette
# Calcul de l'indice de silhouette
sil <- silhouette(km_res$cluster, dist(df_scaled))
fviz_silhouette(sil)  # Visualisation
mean_sil <- mean(sil[, 3])
mean_sil
# Interprétation :
# - Valeur moyenne proche de 1 → Bonne séparation des clusters.
# - Valeur négative → Points mal classés.

# Indice de Davies-Bouldin
library(clusterSim)
db_index <- index.DB(df_scaled, km_res$cluster)$DB
db_index
# Interprétation :
# - Plus l'indice est faible, meilleure est la séparation. 
Davies-Bouldin faible (< 1) → Bonne homogénéité intra-classe

#Inertie Intra-Classe (WSS) et Méthode du Coude
fviz_nbclust(df_scaled, kmeans, method = "wss") + geom_vline(xintercept = 3, linetype = 2)

# Interprétation :
# - Le "coude" (point d'inflexion) suggère le nombre optimal de clusters.

##Évaluation par Critères Externes (si étiquettes connues)

#library(caret)
# Matrice de confusion
conf_matrix <- table(iris$Species, km_res$cluster)
print(conf_matrix)

#ibrary(aricode)

# Calcul du Rand Index ajusté
adjusted_rand <- adjustedRandIndex(iris$Species, km_res$cluster)

# Interprétation :
# - ARI ≈ 1 → Partition identique à la référence.
# - ARI ≈ 0 → Partition aléatoire.

#Pureté
purity <- sum(apply(conf_matrix, 2, max)) / sum(conf_matrix)
print(paste("Pureté :", round(purity, 3)))

# cela signifie que 86.7% des points de données sont correctement regroupés 
dans des clusters où leur classe réelle est majoritaire

##Détermination Automatique du Nombre de Clusters

#Méthode de Gap Statistic
gap_stat <- clusGap(df_scaled, FUN = kmeans, nstart = 25, K.max = 10, B = 50)
gap_stat
fviz_gap_stat(gap_stat)

# Interprétation :
# - Le meilleur k est celui qui maximise le gap statistic. Choisir le plus petit k tel que :
Gap(k)≥Gap(k+1)−sk+1

#Utilisation de NbClust
nbclust_res <- NbClust(df_scaled, distance = "euclidean", min.nc = 2, max.nc = 10, method = "kmeans")
#fviz_nbclust(nbclust_res)
 
# Interprétation :
# - Le nombre optimal est celui choisi par le plus grand nombre d'indices.

#Visualisation des Résultats
# Projection ACP + clusters
fviz_cluster(km_res, data = df_scaled, geom = "point")

# Projection avec deux clusters
km_res_2clusters <- kmeans(df_scaled, centers = 2, nstart = 25)
km_res_2clusters
fviz_cluster(km_res_2clusters, data = df_scaled, geom = "point")

# Dendrogramme (si clustering hiérarchique)
hc <- hclust(dist(df_scaled), method = "ward.D2")
hc
fviz_dend(hc, k = 2, rect = TRUE)

# Interprétation des Résultats

#Silhouette élevée (> 0.5) → Clusters bien séparés.

#Davies-Bouldin faible (< 1) → Bonne homogénéité intra-classe.

#Gap Statistic → k optimal confirmé.

#ARI élevé (si étiquettes connues) → Bonne correspondance avec la réalité.


















