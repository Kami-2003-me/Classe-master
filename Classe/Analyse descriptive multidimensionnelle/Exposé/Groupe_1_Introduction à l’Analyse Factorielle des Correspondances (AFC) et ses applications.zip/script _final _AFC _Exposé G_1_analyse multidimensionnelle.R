
#Supposons que nous disposons d'un tableau de contingence croisant deux variables qualitatives (par exemple, `Profession` et `Type de loisir`).  

#Exemple de tableau de contingence :  
# Création d'un tableau de contingence 
tab_contingence <- matrix(c(
  20, 30, 10,
  15, 25, 20,
  10, 15, 30
), nrow = 3, byrow = TRUE)

rownames(tab_contingence) <- c("Cadre", "Employé", "Ouvrier")
colnames(tab_contingence) <- c("Sport", "Cinéma", "Lecture")

# Affichage du tableau
print(tab_contingence)
#b) Application de l'AFC avec `FactoMineR` 
library(FactoMineR)
library(factoextra)
# Application de l'AFC
res_afc <- CA(tab_contingence, graph = FALSE)
# Visualisation des résultats
summary(res_afc)  # Résumé complet
fviz_ca_biplot(res_afc, repel = TRUE)  # Biplot (visualisation simultanée lignes/colonnes)


# Interprétation des Sorties  
#Valeurs propres et inertie expliquée  
res_afc$eig
#Interprétation : 
#   Dim 1 explique 99,62% de l'inertie (très forte structure).  
#Dim 2 explique 0,38%, complétant l'analyse.  
#On peut se limiter aux 2 premiers axes (100% de l'inertie expliquée). 

# Coordonnées des lignes et colonnes  
#Coordonnées des lignes (professions) : 
res_afc$row$coord
#Interprétation :  
# Cadre et Employé sont du même côté sur Dim 1 (positif), tandis que Ouvrier est opposé (négatif).  
#Dim 1 oppose Cadres/Employés vs Ouvriers.  
#Dim 2 sépare surtout les Cadre/Ouvrier (positif) à Employés. 


#Coordonnées des colonnes (loisirs) :  
res_afc$col$coord
#Interprétation : 
#Sport et Cinéma sont associés aux Cadres/Employés.  
# Lecture est fortement associée aux Ouvriers.  


# Contributions des modalités aux axes  
#Contributions des lignes :  
res_afc$row$contrib
#Interprétation : 
#Cadre et Ouvrier contribuent fortement à Dim 1.  
#Employé contribue surtout à Dim 2.  

#Contributions des colonnes :  
res_afc$col$contrib
#Interprétation :  
#Sport et Cinéma sont fortement associés aux Cadres/Employés.  
#Lecture est associée aux Ouvriers.  

# Qualité de représentation (cos²)  
#Cos² des lignes :  
res_afc$row$cos2
#Interprétation :  
#Cadre et Ouvrier sont très bien représentés sur Dim 1 (cos² élevé).  
#Employé est mieux représenté sur Dim 2.  


#Cos² des colonnes :  
res_afc$col$cos2
#Interprétation :  
#Lecture explique Dim 1.  
#Cinéma et Sport expliquent surtout Dim 2.  



# Visualisation avec `factoextra`  
#a) Biplot (lignes + colonnes)  
fviz_ca_biplot(res_afc, repel = TRUE)
#Interprétation :  
#- Cadre est proche de Sport, Employé est lié à Cinéma, Ouvrier à Lecture.  
#- Plus deux points sont proches, plus leur association est forte.  

# Graphique des lignes
fviz_ca_row(res_afc, repel = TRUE)
#Interprétation :  
# Montre comment les professions se positionnent sur les axes.  

# Graphique des colonnes 
fviz_ca_col(res_afc, repel = TRUE)
#Interprétation :  
#- Montre les associations entre loisirs et axes factoriels. 

#Étape 4 : Validation (test du chi²)
# Test d'indépendance chi²
chi2_test <- chisq.test(tab_contingence)
print(chi2_test)
# Si p-value < 0.05 : Rejet de l'hypothèse d'indépendance → l'AFC est justifiée.




