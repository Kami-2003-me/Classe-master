
#VI. Mise en œuvre dans R (exemple pratique)

#1. Jeu de données

data(iris)
data_numeric <- iris[, -5]

#2. Étape 1 : Évaluer les corrélations

cor(data_numeric)

#3. Étape 2 : Lancer une ACP complète

library(FactoMineR)
if (!requireNamespace("FactoMineR", quietly = TRUE)) {
  install.packages("FactoMineR")
}

res.pca <- PCA(data_numeric, graph = FALSE)
fviz_pca_var(res.pca, col.var = "cos2")

#4. Étape 3 : Supprimer les variables à faible contribution
# Revoir les contributions
res.pca$var$contrib

# Par exemple : supprimer une variable peu contributive et relancer l’ACP
data_reduced <- data_numeric[, -which(names(data_numeric) == "Petal.Width")]
res.pca2 <- PCA(data_reduced, graph = FALSE)

#Ex. manuel :

  data_reduced <- data_numeric[, -which(names(data_numeric) == "Petal.Width")]
  
# 2. Relancer l'ACP
res.pca2 <- PCA(data_reduced, graph = FALSE)

#3. Visualiser les résultats

#Tu peux maintenant visualiser comme avant, par exemple :
  # Afficher la projection des variables
  fviz_pca_var(res.pca2, col.var = "cos2")

# Afficher les individus
  
fviz_pca_ind(res.pca2, col.ind = "cos2")

# Afficher les contributions des variables

res.pca2$var$contrib

