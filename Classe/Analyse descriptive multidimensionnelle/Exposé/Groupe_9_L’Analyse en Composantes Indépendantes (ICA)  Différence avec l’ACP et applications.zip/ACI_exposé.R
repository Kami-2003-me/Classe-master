#On utilise le package fastICA de R.
r
CopierModifier
# Installer le package si besoin
install.packages("fastICA")

# Charger le package
library(fastICA)

# Étape 1 : Génération des sources indépendantes
set.seed(123)  # Pour reproductibilité

# Signal 1 : onde sinusoïdale
S1 <- sin(seq(0, 8 * pi, length.out = 1000))

# Signal 2 : onde carrée (signal binaire +1/-1)
S2 <- sign(sin(seq(0, 4 * pi, length.out = 1000)))

# Combiner les deux signaux en une matrice source
S <- cbind(S1, S2)

# Étape 2 : Mélange linéaire (matrice de mélange A)
A <- matrix(c(0.6, 0.4, 0.4, 0.6), nrow = 2)
X <- S %*% t(A)  # X est la matrice des signaux observés

# Étape 3 : Appliquer l'ICA (FastICA)
ica_result <- fastICA(X, n.comp = 2)

# Étape 4 : Visualisation
par(mfrow = c(3, 1))

plot(S, type = "l", main = "Sources Originales", col = c("blue", "red"))
plot(X, type = "l", main = "Signaux Observés (Mélangés)", col = c("blue", "red"))
plot(ica_result$S, type = "l", main = "Sources Estimées (par ICA)", col = c("blue", "red"))


