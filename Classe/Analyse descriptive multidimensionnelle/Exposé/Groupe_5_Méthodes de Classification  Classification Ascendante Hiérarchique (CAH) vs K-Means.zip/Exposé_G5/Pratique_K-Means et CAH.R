# Chargement des données
data(iris)
iris 
#Commentaire sur IRIS#
#La base est composé de 150 fleurs dont les variables sont :Longueur Sépale;
#Largeur Sépale; Longueur Pétale; Largeur Pétale et la variable qualitative 
#qui est espèce dont les variables sont setosa; versicolor; Virginica.
#Fin commmentaire#  

# Suppression de la colonne "Species" pour faire une classification 
#non supervisée
df <- iris[, -5]
df

#Application de K-means avec k = 3 clusters (groupe)
set.seed(123)  # Pour la reproductibilité
km <- kmeans(df, centers = 3, nstart = 25)
km
print(table(km$cluster))  # pour voir le nombre d'individu dans chaque classe

# Ajout du groupe comme variable dans le data frame iris
iris$KmeansCluster <- as.factor(km$cluster)

# Visualisation (avec ggplot2)
library(ggplot2)

ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width, color = KmeansCluster)) +
  geom_point(size = 3) +
  labs(title = "K-means clustering (k = 3)") +
  theme_minimal()


# Calcul des distances euclidiennes
dist_matrix <- dist(df, method = "euclidean")
print(as.matrix(dist_matrix))


# Classification Ascendante Hiérarchique.
hc <- hclust(dist_matrix, method = "ward.D2")
hc


#Création du dendrogramme
dend <- as.dendrogram(hc)

# Définir les groupes (3 ici)
groups_cah <- cutree(hc, k = 3)

install.packages("dendextend")
# Colorier selon les groupes
dend_colored <- color_branches(dend, k = 3)

# Afficher le dendrogramme colorié
plot(dend_colored, main = "Dendrogramme colorié (Ward.D2)", ylab = "Distance")


# Comparer avec la vraie variable Species
table(Cluster = groups_cah, Espece = iris$Species)

#commentaire
#cluster 1 = 100% setosa
#50 individus, tous sont des setosa.
#Le modèle identifie parfaitement cette espèce car elle est très distincte dans les mesures (pétales/sépales).

#Cluster 2 = versicolor + un peu de virginica
#49 versicolor + 15 virginica
#C’est un cluster un peu mélangé, mais il est majoritairement versicolor.
#Les virginica les plus proches des versicolor sont regroupés ici.

#Cluster 3 = majoritairement virginica
#35 virginica + 1 versicolor
#Ce cluster correspond presque parfaitement à la classe virginica.


# Affichage des clusters obtenus
table(groups_cah)




acp <- PCA(X, graph = FALSE)
class=HCPC(acp,graph=TRUE,nb.par = 150)
class
class$desc.var



